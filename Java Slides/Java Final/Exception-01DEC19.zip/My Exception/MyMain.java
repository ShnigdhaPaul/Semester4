public class MyMain
{
	public static void main(String[]args) throws MyException
	{
		try
		{int a=100;
		 int  b=2;
		 int result=a/b;
			throw new MyException();
		 //System.out.println("Result:\t"+result);
		}
		catch(MyException e)
		{
			System.out.println("Checked My Exception Catch Block");
		}
		
	}
}