public class MyException extends Exception//extends RuntimeException
{
	public MyException()
	{
		System.out.println("My Exception");
	}
	
}