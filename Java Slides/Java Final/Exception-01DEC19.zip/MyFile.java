import java.io.FileReader;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.util.Scanner;
public class MyFile
{
	public static void main(String[] args)throws FileNotFoundException
	{
		try
		{
		FileReader inFile=new FileReader("ABC.txt");
		Scanner sin=new Scanner(inFile);
		String s;
		while(sin.hasNext())
		{
			s=sin.next();
			System.out.println(s);
		}
		}
		catch(FileNotFoundException e)
		{
			System.out.println("File not Found Exception");
		}
		/*catch(IOException e)
		{
			System.out.println("IOException");
		}*/
		
	}
}