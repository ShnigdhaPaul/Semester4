public class MyClass
{
	void show(int a,int b)
	{
		int result=a/b;
		System.out.println("Result:\t"+result);
	}
	public static void main(String[] args)
	{
		int a=10;
		int b=0;
		MyClass ob=new MyClass();
		try
		{
		   ob.show(a,b);
		}
		
		catch(ArithmeticException e)
		{
			System.out.println("Input a value graeter Zero");
		}
				
		catch(Exception e)
		{
			System.out.println("Default Catch Block");
		}
		
	}
}