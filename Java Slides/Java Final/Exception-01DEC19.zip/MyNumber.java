import java.util.Scanner;
import java.util.InputMismatchException;
public class MyNumber
{
	
	public static void main(String[] args)
	{
		int a;
		try
		{
			a=Integer.parseInt(args[0]);
			System.out.println("Value :"+a);
		}
		catch(NumberFormatException e)
		{
			System.out.println("Input Number please");
		}
		
	}
}