public class GUIMain
{
	public static void main(String[] args)
	{
		GUIBasic b1=new GUIBasic();
	}
	
}