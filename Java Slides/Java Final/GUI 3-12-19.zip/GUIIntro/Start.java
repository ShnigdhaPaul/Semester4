public class Start
{
	public static void main(String [] args)
	{
		Form1 f1 = new Form1();
		f1.UI();
		//f1.show();
	}
}