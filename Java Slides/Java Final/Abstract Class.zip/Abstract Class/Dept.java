public abstract class Dept
{
	protected String deptName;
	protected int creditFee;
	public Dept()
	{
	}
	public Dept(String deptName,int creditFee)
	{
		this.deptName=deptName;
		this.creditFee=creditFee;
	}
	
	public abstract void calculateSemesterFee(int credit);
	public void show()
	{
		System.out.println("DeptName: "+deptName);
		System.out.println("Credit Fee: "+creditFee);
	}
}