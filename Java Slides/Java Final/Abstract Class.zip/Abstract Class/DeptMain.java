public class DeptMain
{
	public static void main(String[] args)
	{
		Dept d1;
		d1=new CS("CSE",4500);
		d1.calculateSemesterFee(18);
		d1.show();
		//CS ob=new CS("CSE",4500);
		d1=new BBA("BBA",5500);
		d1.calculateSemesterFee(10);
		d1.show();
		
	}
}