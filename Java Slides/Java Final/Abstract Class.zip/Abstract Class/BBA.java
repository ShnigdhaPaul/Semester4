public class BBA extends Dept
{
	public BBA(String deptName,int creditFee)
	{
		super(deptName,creditFee);
	}
		public void calculateSemesterFee(int credit)
	{
		int semFee=credit*creditFee;
		System.out.println("Semester Fee: "+semFee);
	}
	
}