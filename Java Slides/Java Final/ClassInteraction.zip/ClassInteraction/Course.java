public class Course 
{
	private int courseID;
	private String courseName;
	private char section;
	
	public Course()
	{
		System.out.println("Default Constructor in Course");
	}
	public Course(int courseID,String courseName,char section)
	{
		this.courseID=courseID;
		this.courseName=courseName;
		this.section=section;
		System.out.println("Valued Constructor in Course");
	}
	
	
	public void setCourseValues(int courseID,String courseName,char section)
	{
		this.courseID=courseID;
		this.courseName=courseName;
		this.section=section;
	}
	
	public void showCourseInfo()
	{
		System.out.println("Course Info...........");
		System.out.println("Course Name: "+courseName);
		System.out.println("Course ID: "+courseID);
		System.out.println("Course Section: "+section);
		
	}
	
	
	
}