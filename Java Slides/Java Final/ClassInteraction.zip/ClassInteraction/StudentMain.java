public class StudentMain
{
	public static void main(String[] args)
	{
		Course c1=new Course(1,"JAVA",'A');
		Course c2=new Course(2,"AC",'A');
		Student s1=new Student("1600-2","Ms.Y",3.88,5);
		s1.addCourse(c1);
		s1.addCourse(c2);
	    //s1.setValues("1600-2","Ms.Y",3.88,c1);		
	
		s1.show();
	}
}