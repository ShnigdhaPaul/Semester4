public class Student
{
	private String id;
	private String name;
	private double cgpa;
	private Course[] c;
	private int totalCount=0;
	
	public Student()
	{
		System.out.println("Default Constructor in Student");
	}
	public Student(String id,String name,double cgpa,int no)
	{
		this.id=id;
		this.name=name;
		this.cgpa=cgpa;
		//this.c=c;
		c=new Course[no];
		System.out.println("Valued Constructor in Student");
	}
	public void setValues(String id,String name,double cgpa)
	{
		this.id=id;
		this.name=name;
		this.cgpa=cgpa;
	}
    public void addCourse(Course cob)
	{
		if(totalCount<c.length)
		{
			c[totalCount]=cob;
			totalCount++;
		}
		else
		{
			System.out.println("Not possible ....");
		}
	}
	
	public void show()
	{
		System.out.println("Id :\t"+id);
		System.out.println("Name :\t"+name);
		System.out.println("CGPA :\t"+cgpa);
		for(int i=0;i<totalCount;i++)
		{
			c[i].showCourseInfo();
		}
		
		
		
	}
	
}