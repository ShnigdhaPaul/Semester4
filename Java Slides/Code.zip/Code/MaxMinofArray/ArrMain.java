import java.util.Scanner;

public class ArrMain
{
	public static void main(String[] args)
	{
		
		int[][] a=new int[2][2];
		
		Scanner sin=new Scanner(System.in);
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				System.out.println("Input Value of array["+i+"]["+j+"] :");
				a[i][j]=sin.nextInt();
			}
		}
		int max=a[0][0];
		int min=a[0][0];
		
		int c1=0,r1=0,c2=0,r2=0;
		
		for(int i=0;i<2;i++)
		{
			for(int j=0;j<2;j++)
			{
				if(a[i][j]>max)
				{
					max=a[i][j];
					r1=i;
					c1=j;
				}
				if(a[i][j]<min)
				{
					min=a[i][j];
					r2=i;
					c2=j;
				}
					
			}

		}
		
		System.out.println("Maximum Value Index["+r1+"]["+c1+"]:Value > "+max);
		System.out.println("Minimum Value Index["+r2+"]["+c2+"]:Value > "+min);
		
	}
}






                                         

