public class StudentMain
{
	public static void main(String[] args)
	{
		Student s1=new Student();
	    s1.setValues("1600-2","Ms.Y",3.88);
		
		Student s2=new Student();
	    s2.setValues("1900-2","Mr.X",3.98);
		
		String i=s1.getId();
		String n=s1.getName();
		double c=s1.getCgpa();
		System.out.println("ID by get Method :\t"+i);
		System.out.println("Name by get Method :\t"+n);
		System.out.println("CGPA by get Method :\t"+c);
		
		//System.out.println("ID by get Method :\t"+s1.getId());
		s2.show();
	}
}