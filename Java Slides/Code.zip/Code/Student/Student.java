public class Student
{
	private String id;
	private String name;
	private double cgpa;
	
	public void setValues(String id,String name,double cgpa)
	{
		this.id=id;
		this.name=name;
		this.cgpa=cgpa;
	}
	public String getId()
	{
		return id;
	}
	
	public String getName()
	{
		return name;
	}
	public double getCgpa()
	{
		return cgpa;
	}
	
	public void show()
	{
		System.out.println("Id :\t"+id);
		System.out.println("Name :\t"+name);
		System.out.println("CGPA :\t"+cgpa);
		
	}
	
}