public class Account{
	protected String accId;
	protected String accName;
	protected int balance;
	
	public Account(){
		this("Unknown","Unknown", 0);
		System.out.println("empty constructor");
	}
	public Account(String accId,String name, int balance){
		this.accId=accId;
		this.accName = name;
		this.balance = balance;
		System.out.println("valued constructor");
	}
	public void showInfo(){
		System.out.println("Account Name: "+this.accName);
		System.out.println("Account Balance: "+this.balance);
		System.out.println("----------------------------");
	}		
	public boolean withdraw(int amount){
		if(balance>=amount && amount>0){
			this.balance -=amount; 
			return true;
		}else{
			System.out.println("Invalid Withdraw");
			return false;
		}
	}
	public boolean deposit(int amount){
		if(amount>0){
			this.balance +=amount; return true;
		}else{
			System.out.println("Invalid Deposit");
			return false;
		}
	}
	public void transfer(int amount, Account rec){
		if(this.withdraw(amount)){
			rec.deposit(amount);
		}else{	
			System.out.println("Invalid Transfer");
		}		
	}
}













