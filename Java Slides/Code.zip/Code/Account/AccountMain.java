public class AccountMain{
	public static void main(String [] args){
		System.out.println("Main");
		//Account a = new Account();
		Account a1 = new Account("1a","Sun", 1000);
		Account a2 = new Account("1b","Moon", 2000);
		a1.transfer(5000, a2);
		a1.showInfo();
		a2.showInfo();
		OverDraftAccount d1=new OverDraftAccount("1c","Mars",5000,7000);
		d1.withdraw(11000);
		d1.showInfo();
		
		
	}
}