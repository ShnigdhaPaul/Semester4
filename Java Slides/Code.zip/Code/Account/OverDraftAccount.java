public class OverDraftAccount extends Account 
{
	private int overDraftLimit;
	
	public OverDraftAccount()
	{
		this("Unknown","Unknown",0,0);
		System.out.println("empty constructor in OverDraft Account");
	}
	public OverDraftAccount(String accId,String name, int balance,int overDraftLimit){
		this.accId=accId;
		this.accName = name;
		this.balance = balance;
		this.overDraftLimit=overDraftLimit;
		System.out.println("valued dvl constructor");
	}
	public boolean withdraw(int amount){
		if(balance+overDraftLimit>=amount && amount>0){
			this.balance -=amount;
			return true;
		}else{
			System.out.println("Invalid Withdraw");
			return false;
		}
	}
}