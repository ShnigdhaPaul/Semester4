public class StudentMain
{
	public static void main(String[] args)
	{
		Human h1=new Human();
		//Student s1=new Student("A",23,"Male","1a",4);
		Student s1=new Student();
		s1.setValues("A",23,"Male","1a",4);
		s1.show();
	}
}
