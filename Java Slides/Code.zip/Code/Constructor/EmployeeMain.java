//import java.util.Scanner;
public class EmployeeMain
{
	public static void main(String[] args)
	{
		/*Scanner sin=new Scanner(System.in);
		System.out.println("Input ID: ");
	    String i=sin.next();
		System.out.println("Input Name: ");
	    String n=sin.next();
		System.out.println("Input Salary: ");
	    int s=sin.nextInt();*/
		
		
		Employee e2=new Employee();
		//e2.setValues(i,n,s);
		e2.setValues();
		e2.show();
		Employee e1=new Employee("11-2","ABU",10000);
		e1.show();
		Employee e3=new Employee();
		e3.setValues();
		e3.show();
		Employee.showNo();
		//System.out.println("total Object :"+Employee.no);
	}
}