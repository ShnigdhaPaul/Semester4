import java.util.Scanner;
public class Employee
{
	private String id;
	private String name;
	private int salary;
	//public static int no;
	private static int no;
	
	public Employee()
	{   no++;
		System.out.println(" Default Constructor Called");
	}
	public Employee(String id,String name,int salary)
	{
		no++;
		System.out.println("Valued Constructor Called");
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	/*public void setValues(String id,String name,int salary)
	{
		this.id=id;
		this.name=name;
		this.salary=salary;
	}*/
	
	public void setValues()
	{
		Scanner sin=new Scanner(System.in);
		System.out.println("Input ID: ");
	    String id=sin.next();
		System.out.println("Input Name: ");
	    String name=sin.next();
		System.out.println("Input Salary: ");
	    int salary=sin.nextInt();
		this.id=id;
		this.name=name;
		this.salary=salary;
	}
	public void show()
	{
		System.out.println("Employee Info:>>>>>>>>>>>");
		System.out.println("No:\t"+no);
		System.out.println("ID:\t"+id);
		System.out.println("Name:\t"+name);
		System.out.println("Salary:\t"+salary);
	}
	public static void showNo()
	{
		System.out.println("No:\t"+no);
	}
}