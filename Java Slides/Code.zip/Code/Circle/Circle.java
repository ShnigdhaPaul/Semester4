public class Circle
{
	public static void main(String [] args)
	{		
	double pi,r,a;
	pi=3.1416;
	r=5;
	a=pi*r;
	System.out.println("Area of circle:"+a);
	}
	
}