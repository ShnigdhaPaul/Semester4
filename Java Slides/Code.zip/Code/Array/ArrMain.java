import java.util.Scanner;

public class ArrMain
{
	public static void main(String[] args)
	{
		int a[]=new int[5];
		Scanner sin=new Scanner(System.in);
		//int a[]=new int[]{1,2,3};
		//int a[]={1,2,3};
		
		/*a[0]=10;
		a[1]=20;
		a[2]=30;*/
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println("Input Value of array ["+i+"] : ");
			a[i]=sin.nextInt();
			
		}
		
		for(int i=0;i<a.length;i++)
		{
			System.out.println("Value of array ["+i+"] : "+a[i]);
			
		}
		System.out.println("Array length: "+a.length);
	
	}
}