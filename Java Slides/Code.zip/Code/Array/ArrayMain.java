import java.util.Scanner;

public class ArrayMain
{
	public static void main(String[] args)
	{
		int a[][]=new int[3][4];
		//int a[][]=new int[][]{{1,2,3},{10,20,30},{5,6,7}};
		//int a[][]={{1,2,3},{10,20,30},{5,6,7}};
		Scanner sin=new Scanner(System.in);
		//int a[]=new int[]{1,2,3};
		//int a[]={1,2,3};
		
		/*a[0]=10;
		a[1]=20;
		a[2]=30;*/
		
		for(int i=0;i<3;i++)
		{
			
			for(int j=0;j<4;j++)
			{
				System.out.println("Input Value of array ["+i+"]["+j+"] : ");
				a[i][j]=sin.nextInt();
			}
			
		}
		
		for(int i=0;i<3;i++)
		{
			for(int j=0;j<4;j++)
			{
				System.out.println("Value of array ["+i+"]["+j+"] : "+a[i][j]);
			}
			
		}
		
	
	}
}