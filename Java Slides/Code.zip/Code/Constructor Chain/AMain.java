public class AMain
{
	public static void main(String[] args)
	{
		A ob=new A();
	}
}