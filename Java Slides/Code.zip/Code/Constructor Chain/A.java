public class A
{
	public A()
	{
		this(10);
		System.out.println("Default Constructor");
	}
	public A(int x)
	{
		this(10,50);
		System.out.println("1 para Constructor");
	}
		public A(int x,int y)
	{
		this(3.5,5,"sfdsd");
		System.out.println("2 para Constructor");
	}
		public A(double a,int x,String b)
	{
		System.out.println("3 para Constructor");
	}
}