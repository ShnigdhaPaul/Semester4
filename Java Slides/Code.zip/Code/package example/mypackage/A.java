package mypackage;
public class A
{
	public A()
	{
	System.out.println("My class A");
	}

}