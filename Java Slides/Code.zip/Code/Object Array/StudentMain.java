import java.util.Scanner;
public class StudentMain
{
	public static void main(String[] args)
	{   //int[] x=new int[10];
	    //Student[] ob={new Student("X","1",3),new Student(),new Student()};
		Student[] ob=new Student[3];//Object Array Creation
		Scanner sin=new Scanner(System.in);
		/*ob[0]=new Student();
		ob[1]=new Student();
		ob[2]=new Student();*/
		
		for(int i=0;i<3;i++)
		{
			ob[i]=new Student();
			System.out.println("Input Name :");
			String name=sin.next();
			System.out.println("Input ID :");
			String id=sin.next();
			System.out.println("Input CGPA :");
			double cgpa=sin.nextDouble();
			ob[i].setValues(name,id,cgpa);
			ob[i].show();
		}
		
		
	}
}