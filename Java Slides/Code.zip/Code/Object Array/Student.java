public class Student
{
	private String name;
	private String id;
	private double cgpa;
	
	public Student()
	{
		System.out.println("Default Constructor");
	}
	public Student(String name,String id,double cgpa)
	{
		System.out.println("Valued Constructor");
		this.name=name;
		this.id=id;
		this.cgpa=cgpa;
	}
	public void setValues(String name,String id,double cgpa)
	{
		this.name=name;
		this.id=id;
		this.cgpa=cgpa;
	}
	
	public void show()
	{
		System.out.println("Name:"+name);
		System.out.println("ID:"+id);
		System.out.println("CGPA:"+cgpa);
	}
	
}